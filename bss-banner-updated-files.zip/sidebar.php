<ul class="list-group">
    <li class="list-group-item"><a href="myprofile.php">My Profile</a></li>
    <li class="list-group-item"><a href="changepassword.php">Change Password</a></li>
    <li class="list-group-item"><a href="myorders.php">My Orders</a></li>
    <li class="list-group-item"><a href="logout.php">Logout</a></li>
</ul>