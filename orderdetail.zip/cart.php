<?php
$cart_array = cart();
//print_r($cart_array);
$cartcount = 0;
$quantity = 0;
$totalcost = 0;
for ($i = 0; $i < count($cart_array); $i++) {
    $cartcount += $cart_array[$i]->customers_basket_quantity;
    $totalcost += $cart_array[$i]->final_price;
}
//$cartcount=count($cart_array);
?>

<div class="sc-10mkyz7-0 k0tmtc-5 gaSwzL" id="cartlist">
    <div class="sc-10mkyz7-0 sc-1woi3cc-0 sc-1pm8vvt-0 eKBhGe">
        <div class="sc-10mkyz7-0 sc-1pm8vvt-4 kbozFV">
            <div class="sc-10mkyz7-0 sc-1py8954-5 boakgX">
                <div class="sc-10mkyz7-0 sc-1woi3cc-0 sc-1py8954-2 gbQtPk"><span class="sc-1gu8y64-0 BbwkM sc-1py8954-0 jNzVsZ">Your Cart </span><span class="sc-1gu8y64-0 BbwkM sc-1py8954-1 jXBoSm">(<?php echo $cartcount; ?> Items)</span></div>
            </div>
        </div>
        <div class="sc-10mkyz7-0 sc-16a6ozh-0 kHwhCa sc-1pm8vvt-3 ewaYyg">
            <div class="sc-10mkyz7-0 dWkYtl">
                <div class="sc-10mkyz7-0 sc-1woi3cc-0 cmm1ad-0 bczJcg">
                    <div class="sc-10mkyz7-0 sc-1woi3cc-0 cmm1ad-1 hcBgMh">
                        <!-- loop -->
                        <?php
                        if (count($cart_array) == 0) {
                        ?>
                            <img src="images/no-items-in-cart.png" alt="" title="" width="205px" height="100%" class="sc-1go0t46-0 jKRUzu" />
                            <p class="sc-1gu8y64-0 BbwkM kb1q03-1 cPMUpk">Your cart is empty</p>
                            <p class="sc-1gu8y64-0 BbwkM kb1q03-1 cPMUpk">Add items to get started</p>

                        <?php
                        } else {
                        ?>
                            <?php
                            for ($i = 0; $i < count($cart_array); $i++) {
                                $option_id = $cart_array[$i]->options_id;
                                $product_id = $cart_array[$i]->products_id;
                                $product_name = getProductName($product_id);
                                $quantity = $cart_array[$i]->customers_basket_quantity;
                                $final_price = $cart_array[$i]->final_price;
                                $weight = getOptionWeight($option_id);
                                $unit = getOptionUnit($option_id); ?>

                                <div class="sc-10mkyz7-0 sc-1nivjq8-0 cXkNBx">
                                    <div class="sc-10mkyz7-0 sc-1woi3cc-0 sc-1nivjq8-1 cVDEfY">
                                        <div class="sc-10mkyz7-0 sc-1nivjq8-7 hDia-DB"></div>
                                        <div class="sc-10mkyz7-0 sc-1woi3cc-0 sc-1nivjq8-2 gXSNWL">
                                            <p class="sc-1gu8y64-0 BbwkM sc-1nivjq8-3 GyoxA"><?php echo $product_name; ?></p><button class="sc-59cghl-0 sc-1nivjq8-8 gBkFCe">
                                                <p type="subtitle" class="sc-1gu8y64-0 BbwkM sc-1nivjq8-5 eKVDFK"><?php echo $weight; ?> <?php echo $unit; ?></p>
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16" class="sc-64ptou-0 bXZuJi sc-1nivjq8-10 gzlFHZ mtm9p">
                                                    <path d="M12.594 4L8 8.962 3.406 4 2 5.519 8 12l6-6.481L12.594 4z"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="sc-10mkyz7-0 dWkYtl">
                                            <div width="60px" class="sc-10mkyz7-0 sc-1woi3cc-0 sc-1lv858r-6 gAHkjh sc-1nivjq8-9 jtLufl">
                                                <div class="sc-10mkyz7-0 sc-1woi3cc-0 sc-1lv858r-0 kHHWiy">
                                                    <button class="sc-59cghl-0 sc-1lv858r-4 hTFfdu" onclick="removeCartQuantity(<?php echo $product_id; ?>,<?php echo $option_id; ?>);">-</button>
                                                    <p class="sc-1gu8y64-0 BbwkM sc-1lv858r-5 fJFoxJ mt17pg"><?php echo $quantity; ?></p>
                                                    <button class="sc-59cghl-0 sc-1lv858r-3 cvTPQn" onclick="addCartQuantity(<?php echo $product_id; ?>,<?php echo $option_id; ?>);">+</button>
                                                </div>
                                            </div>
                                        </div>
                                        <p class="sc-1gu8y64-0 BbwkM sc-1nivjq8-4 eVFNQj"><?php echo  "&#8377; " . ($final_price + 0); ?></p>
                                    </div>
                                </div>
                        <?php
                            }
                        }
                        ?>
                        <!-- loop end -->
                    </div>
                </div>
            </div>
        </div>
        <?php
        if (count($cart_array) != 0) {
        ?>
            <div class="sc-10mkyz7-0 sc-1pm8vvt-2 hqvSQU">
                <div class="sc-10mkyz7-0 lmDoJv">
                    <a href="checkout.php" class="text-dec-none">
                        <button shape="circular" size="48" class="sc-1115q80-0 sc-1pm8vvt-5 ePAzTQ">Checkout<p class="sc-1gu8y64-0 BbwkM sc-1pm8vvt-1 cdJVCw mt10px">&#8377;<?php echo number_format((float)$totalcost, 2); ?></p></button>
                    </a>
                </div>
            </div>
        <?php
        } ?>
    </div>
</div>