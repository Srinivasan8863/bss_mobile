<div class="sc-10mkyz7-0 sc-1woi3cc-0 xkwf08-3 bhuMoi">
                <div class="sc-10mkyz7-0 sc-1woi3cc-0 xkwf08-2 bfwbQP">
                    <div class="sc-10mkyz7-0 dFGOFu">
                        <div class="sc-10mkyz7-0 dWkYtl searchBorder">
                            <div class="f7phya-2 ijdHun bfurfe-0 cUEcYs"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="sc-64ptou-0 bXZuJi bfurfe-3 fsvnSB">
                                    <path d="M11 19.023a8 8 0 10.046-16 8 8 0 00-.046 16zM20.994 21.052l-4.337-4.363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg><input value="" placeholder="Search" autofocus="" class="f7phya-0 hQUGbR outline-none"></div>
                        </div>
                    </div>
                </div>
            </div>